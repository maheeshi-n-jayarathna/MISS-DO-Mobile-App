import React from "react"
import { View, Text, TouchableOpacity, StyleSheet } from "react-native"
import { Ionicons } from "@expo/vector-icons" // Import from Expo vector icons

interface TaskItemProps {
  task: any
  navigation: any
}

const TaskItem: React.FC<TaskItemProps> = ({ task, navigation }) => {
  return (
    <View style={styles.taskContainer}>
      <Text style={styles.taskName}>{task.name}</Text>
      <View style={styles.buttonsContainer}>
        <TouchableOpacity
          style={styles.iconButton}
          onPress={() => {
            navigation.navigate("EditTask", { task })
          }}
        >
          <Ionicons name="pencil-outline" size={20} color="#000" />
        </TouchableOpacity>
        <TouchableOpacity style={styles.iconButton} onPress={() => {}}>
          <Ionicons name="trash-outline" size={20} color="#000" />
        </TouchableOpacity>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  taskContainer: {
    backgroundColor: "#fff",
    padding: 16,
    borderRadius: 8,
    marginVertical: 8,
    elevation: 3,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4
  },
  taskName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 10
  },
  buttonsContainer: {
    flexDirection: "row",
    justifyContent: "flex-end",
    gap: 10
  },
  iconButton: {
    backgroundColor: "#dbe1e3",
    padding: 5,
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center"
  }
})

export default TaskItem
