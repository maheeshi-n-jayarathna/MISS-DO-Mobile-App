import React from "react"
import { Appbar } from "react-native-paper"

interface HeaderProps {
  title: string
  goBack?: () => void
}

const Header: React.FC<HeaderProps> = ({ title, goBack }) => {
  return (
    <Appbar.Header>
      {goBack && <Appbar.BackAction onPress={goBack} />}
      <Appbar.Content title={title} />
    </Appbar.Header>
  )
}

export default Header
