import React from "react"
import { View, Text } from "react-native"

const Settings: React.FC = () => {
  return (
    <View>
      <Text>Settings Page</Text>
    </View>
  )
}

export default Settings
