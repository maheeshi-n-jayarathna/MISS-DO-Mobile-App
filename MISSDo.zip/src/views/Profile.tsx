import React, { useContext } from "react"
import { View, Text, Button } from "react-native"
import { AuthContext } from "../auth/AuthContext"

const Profile: React.FC = ({ navigation }: any) => {
  const { user, signOut } = useContext(AuthContext)

  const handleLogout = () => {
    signOut()
    navigation.navigate("Login")
  }

  return (
    <View>
      <Text>Welcome, {user}!</Text>
      <Button title="Logout" onPress={handleLogout} />
    </View>
  )
}

export default Profile
