import React, { useState, useCallback } from "react"
import {
  View,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Text
} from "react-native"
import { useFocusEffect } from "@react-navigation/native"
import { getData } from "../utils/storage"
import TaskItem from "../components/TaskItem"

const Tasks: React.FC = ({ navigation }: any) => {
  const [tasks, setTasks] = useState<any[]>([])

  const loadTasks = async () => {
    const storedTasks = await getData("tasks")
    if (storedTasks) {
      setTasks(JSON.parse(storedTasks))
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadTasks()
    }, [])
  )

  return (
    <View style={styles.container}>
      <FlatList
        data={tasks}
        renderItem={({ item }) => (
          <TaskItem task={item} navigation={navigation} />
        )}
        keyExtractor={(item, index) => index.toString()}
      />
      <TouchableOpacity
        style={styles.fab}
        onPress={() => navigation.navigate("AddTask")}
      >
        <Text style={styles.fabText}>+</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center"
  },
  fab: {
    position: "absolute",
    right: 20,
    bottom: 20,
    backgroundColor: "#000", // add button color
    borderRadius: 50,
    width: 60,
    height: 60,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3.5
  },
  fabText: {
    fontSize: 28,
    color: "#fff",
    fontWeight: "bold"
  }
})

export default Tasks
