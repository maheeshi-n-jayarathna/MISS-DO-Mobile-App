import React, { useState } from "react"
import { View, TextInput, Button } from "react-native"
import { getData, saveData } from "../utils/storage"

const EditTask: React.FC = ({ navigation, route }: any) => {
  const { taskId } = route.params
  const [taskName, setTaskName] = useState("")

  const loadTask = async () => {
    const tasks = await getData("tasks")
    if (tasks) {
      const taskList = JSON.parse(tasks)
      setTaskName(taskList[taskId].name)
    }
  }

  const handleEdit = async () => {
    const tasks: any = await getData("tasks")
    const taskList = JSON.parse(tasks)
    taskList[taskId].name = taskName
    await saveData("tasks", JSON.stringify(taskList))
    navigation.navigate("Tasks")
  }

  React.useEffect(() => {
    loadTask()
  }, [])

  return (
    <View>
      <TextInput
        placeholder="Task Name"
        value={taskName}
        onChangeText={setTaskName}
      />
      <Button title="Edit Task" onPress={handleEdit} />
    </View>
  )
}

export default EditTask
