import React, { useState } from "react"
import { View, TextInput, Button } from "react-native"
import { saveData, getData } from "../utils/storage"

const AddTask: React.FC = ({ navigation }: any) => {
  const [taskName, setTaskName] = useState("")

  const handleAdd = async () => {
    const tasks = (await getData("tasks")) || "[]"
    const updatedTasks = JSON.parse(tasks).concat({ name: taskName })
    await saveData("tasks", JSON.stringify(updatedTasks))
    navigation.navigate("Tasks")
  }

  return (
    <View>
      <TextInput
        placeholder="Task Name"
        value={taskName}
        onChangeText={setTaskName}
      />
      <Button title="Save Task" onPress={handleAdd} />
    </View>
  )
}

export default AddTask
